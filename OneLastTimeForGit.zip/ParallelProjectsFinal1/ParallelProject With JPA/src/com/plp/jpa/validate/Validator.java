package com.plp.jpa.validate;
import com.plp.jpa.dao.BankDAO;
import com.plp.jpa.exep.ValidationException;
public class Validator {
	static BankDAO bankDAO=new BankDAO();
	public static boolean checkName(String name) throws ValidationException{
		int n = name.length();
		char[] ch = name.toCharArray();
		for (int i = 0; i < n; i++) {
			try {
				if (ch[i] > 64 && ch[i] < 122 && ch[0]>63 && ch[0]<90) {
					return true;
				} else {
					throw new ValidationException("Invalid Name");
				}
			} 
			catch (ValidationException e) {
				System.out.println(e);
				return false;
			}
	}
		return false;
	}
	
	public static boolean isNameValid(String name) {
		if(name.matches( "[A-Z][a-z]*" )) {
			return true;
		}
		else {
			return false;
		}
	}
	public static boolean checkPhoneNumber(String number)
	{
		if(number.matches("[0-9]+") && number.length()==10)
		{
			return true;
		}
		else
		{
			System.out.println("Invalid Phone Number");
			return false;
		}
	}
	public static boolean checkAccNo(int accountNumber)
	{
		if(bankDAO.checkAccNo(accountNumber)) 
		{
			return true;
		}
		else
		{
			System.out.println("Invalid Account Number");
		    return false;
		}
     }
}
