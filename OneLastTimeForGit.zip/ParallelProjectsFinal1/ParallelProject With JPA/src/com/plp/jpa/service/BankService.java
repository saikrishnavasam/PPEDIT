package com.plp.jpa.service;

import com.plp.jpa.dao.BankDAO;
import com.plp.jpa.entity.Bank;

public class BankService {
	
	BankDAO bankDAO = new BankDAO();

	public void addAccount(Bank bank) {
		bankDAO.beginTransaction();
		bankDAO.addUserAccount(bank);
		bankDAO.commitTransaction();
	}

	public Bank checkBalance(int accountNo)
	{
		Bank bank=bankDAO.getBalance(accountNo);
		return bank;
		
	}

	public Bank depositMoney(int accountNumber,long amount,String tran) {
		bankDAO.beginTransaction();
		Bank bank=bankDAO.depositMoney(accountNumber,amount,tran);
		bankDAO.commitTransaction();
		return bank;
	}

	public Bank withdrawMoney(int accNumber1, long amount,String tran) {
		bankDAO.beginTransaction();
		Bank bank=bankDAO.withdrawMoney(accNumber1,amount,tran);
		bankDAO.commitTransaction();
		return bank;
		
	}

	public String getTransactionDetails(int accountNumber) {
		String tran=bankDAO.getTransaction(accountNumber);
		return tran;
	}


}
