import { Component, OnInit } from '@angular/core';
import { CustomerServiceService } from '../customer-service.service';
import { ShowBalanceComponent } from '../show-balance/show-balance.component';

@Component({
  selector: 'app-cash-transfer',
  templateUrl: './cash-transfer.component.html',
  styleUrls: ['./cash-transfer.component.css']
})
export class CashTransferComponent implements OnInit {

  constructor(private customerService: CustomerServiceService,private show: ShowBalanceComponent) { }
  balance:number;
  ngOnInit() {
  }

  cashTransfer(accountNo,recaccountNo,amount)
 { 
this.customerService.cashTransfer(accountNo,recaccountNo,amount).subscribe(data => {
if(data===1)
{
  window.alert('Transfer Successful');
  this.balance=this.show.showBalance(accountNo);
}
else{
  window.alert('Money Not Transferred.Try Again');
}
 });
}
}
