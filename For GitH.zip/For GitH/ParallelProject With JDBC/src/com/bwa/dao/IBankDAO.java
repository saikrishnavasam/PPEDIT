package com.bwa.dao;

import java.sql.SQLException;
import java.util.HashMap;

import com.bwa.bean.Bank;
import com.bwa.bean.Transaction;
import com.bwa.exception.BankUserInputException;

public interface IBankDAO {
	
	public void addUserAccount(Bank bank,Transaction tran) ;
	
	public String getBalance(int accountNo) ;
	
	public String depositMoney(int accountNumber,long amount,Transaction tran) ;
	
	public String withdrawMoney(int accountNumber,long amount,Transaction tran);
	
	public HashMap<Integer,Transaction> printTransactions(int  accountId)  ;	

	public String transferMoney(int accountNumber01, long amount01, int accountNumber02,Transaction tran1,Transaction tran2) ;


	
}
